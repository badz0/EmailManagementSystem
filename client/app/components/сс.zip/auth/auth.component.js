import controller from './auth.controller';

let authComponent = {
  controller
};

export default authComponent;
