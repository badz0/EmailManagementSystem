class AuthController {
  constructor(AuthService,authManager) {
  	'ngInject';
    this.AuthService = AuthService;
    this.AuthService.registerAuthenticationListener();
    this.name = "name";
  }
}

export default AuthController;
