import authModule from './auth'
import AuthController from './auth.controller'
import authComponent from './auth.component'
import AuthService from './auth.service'
import AuthRun from './auth.run'

describe('Auth', () => {

  beforeEach(angular.mock.module(authModule));

  describe('Component', () => {
    let component = authComponent;
    it('SSSinvokes the right controller', () => {
      expect(component.controller).toEqual(AuthController);
    });
  });

  describe('Controller', () => {
    it('has a name property', () => { // erase if removing this.name from the controller
      expect(AuthController.name).toBeDefined();
    });
  });

  describe('Service', () => {
    let authService;
    beforeEach(() => {
      authService = new AuthService();
    });
    it('has a name property', () => {
      expect(authService.name).toBeDefined();
    });
    it('have 5 function', () => {
      expect(authService.login).toBeDefined();
      expect(authService.logout).toBeDefined();
      expect(authService.registerAuthenticationListener).toBeDefined();
      expect(authService.isAuthenticated).toBeDefined();
      expect(authService.getProfileDeferred).toBeDefined();
    });
  });

  describe('Function of service', () => {
    let $state, $rootScope, $stateProvider, deferredProfile, lock, authManager;
    beforeEach(inject((_$rootScope_, _$state_, _authManager_, _lock_) => {
      $rootScope = _$rootScope_;
      $state=_$state_;
      authManager=_authManager_;
      lock=_lock_;
    }));
    it('Can show plugin', () => {
      expect(lock.show).toBeDefined();
    });
    it('Can get clientID and domain from Auth0 client', ()=> {
      expect(Auth0Lock).toBeDefined();
    });
    it('Can authenficated', () => {
      expect(lock.on).toBeDefined();
    });
    it('Can get users info', () => {
      expect(lock.getUserInfo).toBeDefined();
    });
    it('Can refresh page', () => {
      expect($state.go).toBeDefined();
    });
    it('isAuthenticated?', () => {
      expect(authManager.isAuthenticated).toBeDefined();
    });
    it('isUnAuthenticated?', () => {
      expect(authManager.unauthenticate).toBeDefined();
    });
  });

  describe('Run component', () => {
    let lock, authManager, authService;
    beforeEach(() => {
      authService = new AuthService();
    });
    beforeEach(inject((_authManager_, _lock_) => {
      authManager=_authManager_;
      lock=_lock_;
    }));
    it('run function', () => {
      expect(authService.login).toBeDefined();
      expect(authService.registerAuthenticationListener).toBeDefined();
      expect(authManager.checkAuthOnRefresh).toBeDefined();
      expect(lock.interceptHash).toBeDefined();
    });
  });

  describe('init', function () {
    it('should handle a single client', function () {
      executeInConfigBlock(function (lockProvider) {
        lockProvider.init({
        domain: 'my-domain.auth0.com',
        clientID: 'my-client-id',
        callbackURL: 'http://localhost/callback'
        });
      });
    inject(function (auth) { expect(auth).to.be.ok; });
    });
  });
    //     it('should allow passing a different constructor', function () {

    //         var MyAuth0Constructor = function () {
    //             this.getProfile = function () {};
    //         };
    //         executeInConfigBlock(function (authProvider) {
    //             authProvider.init({
    //                 domain: 'my-domain.auth0.com',
    //                 clientId: 'my-client-id',
    //                 callbackURL: 'http://localhost/callback'
    //             }, MyAuth0Constructor);
    //         });

    //         inject(function (auth) {
    //             expect(auth).to.be.ok;
    //             expect(auth.config.auth0lib.constructor).to.be.equal(MyAuth0Constructor);
    //         });
    //     });
});